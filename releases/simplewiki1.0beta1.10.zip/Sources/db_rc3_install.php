<?php
/*
SimpleWiki Database modification
Version: SimpleWiki 1.0 Beta 0.09
*/
/*
if(!defined('SMF')&&!file_exists(dirname(__FILE__).'/SSI.php'))
	die('SSI.php cannot be found');
if(!defined('SMF')&&file_exists(dirname(__FILE__).'/SSI.php'))
	require_once('SSI.php');
*/
db_extend('packages');

///////////////////////////////
$tables[] = array(
	'table_name' => '{db_prefix}wiki_files',
	'collumns' => array(
		array(
			'name' => 'id_file',
			'auto' => true,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
		array(
			'name' => 'name',
			'auto' => false,
			'default' => 0,
			'type' => 'varchar',
			'size' => 255,
			'null' => false,
		),
		array(
			'name' => 'id_member',
			'auto' => false,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
		array(
			'name' => 'time',
			'auto' => false,
			'default' => 0,
			'type' => 'int',
			'size' => 11,
			'null' => false,
		),
	),
	'indexes' => array(
		array(
			'columns' => array('id_file'),
			'type' => 'primary',
		),
	),
	'if_exists' => 'update',
	'error' => 'fatal',
	'parameters' => array(),
);
$tables[] = array(
	'table_name' => '{db_prefix}wiki_bans',
	'columns' => array(
		array(
			'name' => 'id_ban',
			'auto' => true,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
		array(
			'name' => 'ip',
			'auto' => false,
			'default' => 0,
			'type' => 'varchar',
			'size' => 100,
			'null' => false,
		),
		array(
			'name' => 'user',
			'auto' => false,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
	),
	'indexes' => array(
		array(
			'columns' => array('id_ban'),
			'type' => 'primary',
		),
	),
	'if_exists' => 'update',
	'error' => 'fatal',
	'parameters' => array(),
);
$tables[] = array(
	'table_name' => '{db_prefix}wiki_categories',
	'columns' => array(
		array(
			'name' => 'cat_name',
			'auto' => false,
			'default' => 0,
			'type' => 'varchar',
			'size' => 130,
			'null' => false,
		),
		array(
			'name' => 'page_name',
			'auto' => false,
			'default' => 0,
			'type' => 'varchar',
			'size' => 140,
			'null' => false,
		),
	),
	'indexes' => array(
	),
	'if_exists' => 'update',
	'error' => 'fatal',
	'parameters' => array(),
);
$tables[] = array(
	'table_name' => '{db_prefix}wiki_pages',
	'columns' => array(
		array(
			'name' => 'id',
			'auto' => true,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
		array(
			'name' => 'title',
			'auto' => false,
			'default' => 0,
			'type' => 'varchar',
			'size' => 140,
			'null' => false,
		),
		array(
			'name' => 'time',
			'auto' => false,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
		array(
			'name' => 'user',
			'auto' => false,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
		array(
			'name' => 'ip',
			'auto' => false,
			'default' => 0,
			'type' => 'varchar',
			'size' => 100,
			'null' => false,
		),
		array(
			'name' => 'content',
			'auto' => false,
			//'default' => 0,
			'type' => 'text',
			'null' => false,
		),
		array(
			'name' => 'protected',
			'auto' => false,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
		array(
			'name' => 'deleted',
			'auto' => false,
			'default' => 0,
			'type' => 'int',
			'size' => 10,
			'null' => false,
		),
		array(
			'name' => 'views',
			'auto' => false,
			'default' => 0,
			'type' => 'int',
			'size' => 15,
			'null' => false,
		),
		array(
			'name' => 'reason',
			'auto' => false,
			'type' => 'text',
			'null' => false,
		),
	),
	'indexes' => array(
		array(
			'columns' => array('id'),
			'type' => 'primary',
		),
	),
	'if_exists' => 'update',
	'error' => 'fatal',
	'parameters' => array(),
);

foreach ($tables as $table)
	$smcFunc['db_create_table']($table['table_name'], $table['columns'], $table['indexes'], $table['parameters'], $table['if_exists'], $table['error']);
//tables created, now test to see wether we need to insert 'Wiki:Menu' or 'Main Page'
$wikitxt = array(
	'main_page' => '[center][size=2em][color=limegreen]Simple[/color][color=red]Wiki[/color][/size][/center]
[header1]What is SimpleWiki?[/header1]
SimpleWiki is a wiki software written in PHP and SQL by Colonel Sorck.
[header1]Features[/header1]
SimpleWiki has a large variety of features, we attempt to have them fully documented here.
[header2]Editting[/header2]Users can edit pages with a text editor as well as a WYSIWYG editor, this means pages can be quickly editted by anyone (there are currently some bugs with the WYSIWYG editor, and we cannot see why it\'s not working properly)
[header2]History[/header2]As no pages are ever overwritten or deleted from the database vandalism can easily be reversed.
[header2]Search (unreleased)[/header2]A simplistic search feature allows users to simply and effectivley search for any information they would like.
[header2]Categories[/header2]From user feedback, categories were a popular feature that people wanted to see in SimpleWiki. These can be declaired using the [categories][/categories] tags.
[header2]Syntax[/header2][color=limegreen]Simple[/color][color=red]Wiki[/color] allows for standard BBCode syntax as well as some wiki-style syntax, certain HTML codes may be enabled but this depends upon the administrators settings.[header1]System Requirements[/header1][color=limegreen]Simple[/color][color=red]Wiki[/color] will run on any HTTP web server which runs PHP and one of the following SQL databases:
[list][li]MySQL[/li][li]PostreSQL[/li][li]SQLite[/li][/list][header1]Script conflicts[/header1]No conflicts with any standard code has been found.
[header1]Themes[/header1][color=limegreen]Simple[/color][color=red]Wiki[/color] works with both SMF Core and SMF Curve with no compatability errors, it may not work in custom themes.',
	'menu' => '[menu]
[menu-cat=Main]
[menu-li=index.php?action=wiki;p=Main Page]Main Page[/menu-li]
[menu-li=index.php?action=wiki;p=Wiki:Menu]Edit Menu[/menu-li]
[/menu-cat]
[menu-cat=Toolbox]
[menu-li=index.php?action=wiki;sa=v_all]View all SimpleWiki pages[/menu-li]
[/menu-cat]
[menu-cat=Links]
[menu-li=http://simplewiki.co.uk]SimpleWiki[/menu-li]
[menu-li=http://www.simplemachines.org]Simple Machines[/menu-li]
[/menu-cat]
[/menu]',
);
$required = array('Main Page' => $wikitxt['main_page'], 'Wiki:Menu' => $wikitxt['menu']);
foreach($required as $act => $item)
{
	$res = $smcFunc['db_query']('', 'SELECT * FROM {db_prefix}wiki_pages WHERE title = {string:txt}', array('txt' => $act));
	if(!is_array($smcFunc['db_fetch_assoc']($res)))
	{
		$smcFunc['db_insert']('insert', '{db_prefix}wiki_pages', array(
			'title' => 'text', 'time' => 'int', 'ip' => 'text', 'user' => 'int', 'content' => 'text', 'protected' => 'text'
		),
		array(
			$act, time(), '127.0.0.1', 0, $item, '1'
		));
	}
}
?>