[center][size=4]SimpleWiki 1.0 Beta 1[/size][br]Author: Colonel Sorck[/center]
SimpleWiki is a powerful Wiki intergration for SMF 2.
As this is a beta there is no included documentation, also this readme will be expanded for it's release.
[i]Although this is a beta I've still got to mention the liscence :P[/i]
[size=1]THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY WARRANTY. ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES ARISING IN ANY WAY OUT OF THE USE OR MISUSE OF THIS PACKAGE.[/size]