<?php
/*
wiki.template.php Copyright (c) 2010 J Robson
*/
function template_main()
{
	global $txt, $context, $user_info;
	foreach($context['wiki_reports'] as $act => $item)
	{
		echo '<div class="errorbox">'.$item.'</div>';
	}
	echo '<div class="title_bar">
			<h3 class="titlebg">
			<div id="quick_search" class="align_right"><form action="index.php?action=wiki;sa=search" method="post">
			<input class="input_text" type="text" name="q" value="'.$txt['search'].'" /></form></div>'.$txt['wiki'].'</h3>
	</div><span class="upperframe"><span></span></span>
	<div class="roundframe">'.sprintf($txt['wiki_welcome'], ($user_info['name']?$user_info['name']:$txt['guest'])).'
	</div><span class="lowerframe"><span></span></span>';
	//fetch the menu from the database via normal fetch page
	$tmenu = wiki_fetch_page('Wiki:Menu');
	//use modded bbc parser
	define('MENU_BBC', 1);
	echo '<br /><div id="left_admsection">';
	echo wiki_parse($tmenu['content']);
	echo '</div>';
	echo '<div class="windowbg2" id="main_admsection"><span class="topslice"><span></span></span><div class="content">';
	if(function_exists('template_wiki_'.$context['wiki_template']))
		call_user_func('template_wiki_'.$context['wiki_template']);
	echo '</div><span class="botslice clear"><span></span></span></div><br class="clear" />';
	template_wiki_copyright();
}

function template_wiki_manage_bans()
{
	if(isset($_REQUEST['updated']))
		echo '<div class="errorbox>Ban added!</div>';
}

function template_wiki_search()
{
	global $context, $txt;
	echo '<h1>'.(isset($_REQUEST['q'])?sprintf($txt['wiki_search_query'], $_REQUEST['q']):$txt['search']).'</h1>';
	$results = $context['wiki_search_results'];
	echo '<ul>';
	foreach($results as $act => $page)
	{
		echo '<li><a href="'.$scripturl.'?action=wiki;p='.$page['title'].'">'.$page['title'].'</a></li>';
	}
	echo '</ul>';
}

function template_wiki_create()
{
	template_wiki_edit_box($scripturl.'?action=wiki;sa=save;p='.$_REQUEST['p'], true);
}

function template_wiki_history()
{
	global $context, $scripturl, $txt;
	$tools = array('back_2_page' => array('url'=>$scripturl.'?action=wiki;p={page:string}', 'show'=>true, 'name'=>'wiki_back2page', 'image' => 'wiki_back.png'));
	$toolbar = template_wiki_make_toolbar($tools);
	echo $toolbar;
	echo $context['history_pageIndex'].'<br />';
	echo '<ul>';
	foreach($context['history_pages'] as $act => $row)
	{
		echo '<li>';
		if(wikiAllowedTo('wiki_delete')&&$row['deleted']=='0')
			echo '<a href="'.$scripturl.'?action=wiki;sa=delete;id='.$row['id'].'">('.$txt['wiki_delete_abrev'].')</a> ';
		elseif(wikiAllowedTo('wiki_delete')&&$row['deleted']=='1')
			echo '<a href="'.$scripturl.'?action=wiki;sa=delete;id='.$row['id'].'">('.$txt['wiki_undelete_abrev'].')</a> ';
			
		echo '<a href="'.$scripturl.'?action=wiki;id='.$row['id'].'">'.timeformat($row['time']).'</a>';

		echo ' - <a href="'.$scripturl.'?action=wiki;p=User:'.urlencode(($row['member_name']?$row['member_name']:$row['ip'])).'">'.($row['real_name']?$row['real_name']:$row['ip']).'</a>';
		if(wikiAllowedTo('wiki_admin')&&!empty($row['member_name']))
			echo '(<a href="'.$scripturl.'?action=wiki;p=User:'.urlencode($row['ip']).'">'.$row['ip'].'</a>)';
		echo '</li>';
	}
	echo '</ul>';
}

function template_wiki_copyright()
{
	// THIS MUST REMAIN, REMOVING AND/OR MODIFYING IT IS ILLEGAL WITHOUR PERMISSION
	echo '<div class="centertext smalltext"><a href="http://simplewiki.co.uk">SimpleWiki &copy; 2010, Colonel Sorck</a></div>';
}

function template_wiki_admin()
{
	// !!! needs work, in fact it needs moving to the admin cpanel
	echo wiki_parse('[header1]Admin[/header1][header2]H2[/header2]');
	echo '<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="MQG4FJTN6SAM2">
<input type="image" src="https://www.paypal.com/en_US/GB/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypal.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form><br />
';
echo '<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="KSZ6BXMSVBPXE">
<input type="image" src="https://www.paypal.com/en_GB/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypal.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
';
}

function template_wiki_protect()
{
	global $context, $txt, $smcFunc;
	$tools = array(
		'back_to_page' => array('name'=>'wiki_back2page', 'show'=>true, 'url'=>'index.php?action=wiki;p={page:string}', 'image' => 'wiki_back.png'),
		'history' => array('name'=>'wiki_history', 'show'=>wikiAllowedTo('wiki_view_history'), 'url'=>'index.php?action=wiki;sa=history;p={page:string}', 'image' => 'wiki_history.png'),
	);

	$toolbar = template_wiki_make_toolbar($tools);
	echo $toolbar;
	//now for the form
	echo '<form action=\'index.php?action=wiki;sa=protect;p='.$_REQUEST['p'].';save\' method=\'post\'>';
	echo '<select name=\'protect_form\'>';
	foreach($context['wiki_protect_options'] as $act => $option)
	{
		if($option['show'])
		{
			echo '<option value=\''.$option['value'].'\' '.(intval($context['wiki_page']['protected'])==$option['key']?'selected=\'1\'':'').'>'.$option['text'].'</option>';
		}
	}
	echo '</select><br />';
	/*//groups list
	$res = $smcFunc['db_query']('', 'SELECT * FROM {db_prefix}membergroups WHERE min_posts=\'-1\'', array());
	$groups = array();
	while($group = $smcFunc['db_fetch_assoc']($res))
	{
		$groups[] = $group;
	}*/
	//echo '<input type=\'checkbox\' name=\'group\' value=\'1\' /><br />';
	echo '<br /><input type=\'submit\' value=\''.$txt['wiki_protect_page'].'\'><br />';
	echo '</form>';
}

function template_wiki_make_toolbar($tools)
{
	$toolbar = '<span class="float_right">';
	foreach($tools as $act => $tool)
	{
		$tool['url'] = str_replace(array('{page:string}'), array($_REQUEST['p']), $tool['url']);
		if($tool['show'])	
			//$toolbar .= '<a href="'.$tool['url'].'">['.$tool['name'].']</a>';
			$toolbar .= '<a href="'.$tool['url'].'">'.create_button($tool['image'], $tool['name'], $tool['name']).'</a>';
	}
	$toolbar .= '</span>';
	return $toolbar;
}

function template_wiki_view_all()
{
	global $context, $txt, $scripturl;
	echo constructPageIndex($scripturl.'?action=wiki;sa=v_all', intval($_REQUEST['start']), $context['wiki_nrows'], 25);
	echo '<ul>';
	foreach($context['wiki_page_list'] as $page)
	{
		echo '<li><a href="'.$scripturl.'?action=wiki;p='.htmlspecialchars($page).'">'.htmlspecialchars($page).'</a></li>';
	}
	echo '</ul>';
}

function template_wiki_page()
{
	global $context, $txt;	
	$tools = array(
		'edit' => array('name'=>'wiki_edit', 'show'=>wikiAllowedTo('wiki_edit')&&!isset($_REQUEST['id']), 'url'=>'index.php?action=wiki;sa=edit;p={page:string}', 'image' => 'wiki_edit.png'),
		'history' => array('name'=>'wiki_history', 'show'=>wikiAllowedTo('wiki_view_history'), 'url'=>'index.php?action=wiki;sa=history;p={page:string}', 'image' => 'wiki_history.png'),
		'protect' => array('name'=>'wiki_protect_page', 'show'=>wikiAllowedTo('wiki_protect'), 'url'=>'index.php?action=wiki;sa=protect;p={page:string}', 'image' => 'wiki_lock.png'),
		'create' => array('name'=>'wiki_create_new_page', 'show'=>wikiAllowedTo('wiki_create'), 'url'=>'index.php?action=wiki;sa=create', 'image' => 'wiki_create.png'),
	);

	$toolbar = template_wiki_make_toolbar($tools);
	echo $toolbar;
	if(function_exists('template_wiki_namespace_'.$context['name_space']))
		call_user_func('template_wiki_namespace_'.$context['name_space']);
	echo $context['wiki_page_content'];
}

function template_wiki_namespace_cat()
{
	global $context, $txt, $scripturl;
	echo '<div class="largetext">'.sprintf($txt['wiki_pages_in_cat'], htmlspecialchars($_REQUEST['p_no_namespace'])).'</div>';
	echo '<ul>';
	foreach($context['wiki_catinfo'] as $act => $page)
	{
		echo '<li><a href="'.$scripturl.'?action=wiki;p='.$page['page_name'].'">'.$page['page_name'].'</a></li>';
	}
	echo '</ul><hr />';
}

function template_wiki_namespace_file()
{
	global $context;
	// !!! needs some stuff to display!
}

function template_wiki_namespace_user()
{
	global $txt, $context, $scripturl, $modSettings, $settings, $options;
	if(!$context['wiki_user'])
		return;
	echo '<hr />';
		echo '<dl>';
		echo '<dt>'.$txt['username'].'</dt><dd>'.$context['wiki_user']['real_name'].'</dd>';
		echo '<dt>'.$txt['email'].'</dt><dd><a href="', $scripturl, '?action=emailuser;sa=email;uid=', $context['wiki_user']['id'], '" title="', $context['member']['show_email'] == 'yes' || $context['member']['show_email'] == 'yes_permission_override' ? $context['member']['email'] : '', '" rel="nofollow"><img src="', $settings['images_url'], '/email_sm.gif" alt="', $txt['email'], '" /></a></dd>';
		echo '<dt>'.$txt['posts'].'</dt><dd>'.$context['wiki_user']['posts'].'</dd>';
		echo '</dl>';
	
	echo '<hr />';
}

function template_wiki_edit()
{
	global $txt, $scripturl;
	template_wiki_edit_box($scripturl.'?action=wiki;sa=save;p='.$_REQUEST['p']);
	echo '<form method="post" action="index.php?action=wiki;p='.$_REQUEST['p'].'"><input type="submit" value="'.$txt['wiki_cancel_editting'].'" /></form>
	<form action="index.php?action=wiki;sa=edit;p='.$_REQUEST['p'].';preview" methos="post"><input type="submit" value="'.$txt['wiki_edit_preview_button'].'" /></form>';
}

function template_wiki_edit_box($action, $titlebox = false)
{
		global $txt;
	echo'<h2>'.$txt['title'].':</h2> <form action="'.$action.'" method="post">';
	if($titlebox)echo '<input type="text" value=\''.htmlspecialchars($_REQUEST['p']).'\' name="p" />';
	echo '<div id="bbc"></div><div id="smileys"></div>';
	template_control_richedit('wiki_content', 'smileys', 'bbc');
	echo '<input type="submit" value="'.$txt['wiki_save_button'].'" /></form>';
}
?>