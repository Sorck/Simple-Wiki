<?php
function wiki_namespace_user()
{
	global $txt, $context, $scripurl, $smcFunc, $sourcedir;
	//set the name space...
	$context['name_space'] = 'user';
	//is the user declaired? no point querying for nothing
	require_once($sourcedir.'/Profile-View.php');
	//if(!$_REQUEST['p_no_namespace'])
	//	return;
	// !!! should this respect permissions from normal profile viewing?
	$sql = 'SELECT * FROM {db_prefix}members WHERE member_name = {string:user}';
	$res = $smcFunc['db_query']('', $sql, array('user'=>$_REQUEST['p_no_namespace']));
	$row = $smcFunc['db_fetch_assoc']($res);
	if(empty($row))
		$context['wiki_user'] = false;
	else
		$context['wiki_user'] = $row;
}
?>