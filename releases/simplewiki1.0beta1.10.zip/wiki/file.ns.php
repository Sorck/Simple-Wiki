<?php
/*
file.ns.php
the houses the file namespace for SimpleWiki
*/

function wiki_namespace_file()
{
	global $context, $smcFunc;
	$sa = array(
		'upload' => 'wiki_upload_file',
		'download' => 'wiki_download_file',
	);
	$res = $smcFunc['db_query']('', 'SELECT f.name AS filename, f.id_file AS id, u.*
									FROM {db_prefix}wiki_files AS f LEFT JOIN {db_prefix}members AS u
										ON f.id_member = u.id_member
									WHERE f.name = {text:file}
									ORDER BY f.id DESC',
									array('file' => $_REQUEST['p_no_namespace']));
	$context['name_space'] = 'file';
	if(isset($_REQUEST['sa']) && isset($sa[$_REQUEST['sa']]))
		call_user_func($sa[$_REQUEST['sa']]);
}

function wiki_upload_file()
{
	if(isset($_FILE['wiki']))
		wiki_upload_file2();
}

function wiki_upload_file2()
{
	
}

function wiki_file_from_db($file, $number = )
{
	global $smcFunc, $boarddir;
	$res = $smcFunc['db_query']('', 'SELECT f.name AS filename, f.id_file AS id, u.*
									FROM {db_prefix}wiki_files AS f LEFT JOIN {db_prefix}members AS u
										ON f.id_member = u.id_member
									WHERE f.name = {text:file}
									ORDER BY f.id DESC
									LIMIT 0,1', array('file' => $file));
	if(!$res)
		return false;
	else
		return $smcFunc['db_fetch_assoc']($res);
}

function wiki_download_file()
{
	global $boarddir, $smcFunc;
	//check the database to make sure the file exists and what it's id is
	$file = wiki_file_from_db($_REQUEST['p_no_namespace']);
	$file = $file['filename'];
	
	// place this code inside a php file and call it f.e. "download.php"
	$path = $boarddir.'/wiki_files/'; // change the path to fit your websites document structure
	$fullPath = $path.$file;
	
	if ($fd = fopen ($fullPath, "r")) {
		$fsize = filesize($fullPath);
		$path_parts = pathinfo($fullPath);
		$ext = strtolower($path_parts["extension"]);
		switch ($ext) {
			case "pdf":
			header("Content-type: application/pdf"); // add here more headers for diff. extensions
			header("Content-Disposition: attachment; filename=\"".$path_parts["basename"]."\""); // use 'attachment' to force a download
			break;
			default;
			header("Content-type: application/octet-stream");
			header("Content-Disposition: filename=\"".$path_parts["basename"]."\"");
		}
		header("Content-length: $fsize");
		header("Cache-control: private"); //use this to open files directly
		// !!! maybe we should kill the object buffer now
		while(!feof($fd)) {
			$buffer = fread($fd, 2048);
			echo $buffer;
		}
	}
	else
		fatal_error('Unable to find file.');
	fclose ($fd);
	die();
}
?>