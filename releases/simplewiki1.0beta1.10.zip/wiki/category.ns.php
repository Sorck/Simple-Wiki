<?php
function wiki_namespace_category()
{
	global $smcFunc, $context;
	//fetch all pages
	$res = $smcFunc['db_query']('', 'SELECT * 
		FROM {db_prefix}wiki_categories
		WHERE cat_name={string:cat}',
		array('cat'=>$_REQUEST['p_no_namespace']));
	$context['name_space'] = 'cat';
	$catinfo = array();
	while($row = $smcFunc['db_fetch_assoc']($res))
	{
		$catinfo[] = $row;
	}
	$context['wiki_catinfo'] = $catinfo;
}
?>